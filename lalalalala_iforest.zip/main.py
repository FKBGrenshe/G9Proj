from config import trainDatasetCSV, validDatasetCSV, moduleSavePath;
from train import *;
from valid import *;
from data_process import *;
import os
from utils import *;


# 这是主程序入口
def main():
    print("=" * 70)
    print("  异常检测系统 - 支持训练、验证和 Kaggle 提交")
    print("=" * 70)
    ## 输入 train 即重新训练一个模型并进行保存，输入valid 即使用已有模型进行验证，输入submit生成Kaggle提交文件
    mode = input("\n请输入模式 (train/valid/submit): ").strip().lower()
    if mode == 'train':
        ##############################################
        ################ 最终路径 #####################
        ##############################################
        trainDatasetCSVRootDir = get_full_path(trainDatasetCSV)
        model_name = input("请输入要保存的模型名称 (例如 'trained_model'): ").strip()
        moduleSaveRootDir = os.path.join(get_full_path(moduleSavePath), f"{model_name}.joblib")
        print("moduleSaveRootDir =", moduleSaveRootDir)

        ##############################################
        ################ 预处理&模型训练 ##############
        ##############################################
        # 预处理训练数据
        processed_training_data = preprocess_for_training(trainDatasetCSVRootDir)
        if processed_training_data is None:
            print("数据预处理失败，训练中止。")
            return
        # 训练并保存模型
        train_and_save_model(processed_training_data, moduleSaveRootDir)

    elif mode == 'valid':
        # 从已经保存模型中进行验证
        # 输入模型名称，如果savedModule中没有该模型则报错
        model_name = input("请输入已训练模型的名称 (例如 'trained_model'): ").strip()
        model_file = os.path.join(get_full_path(moduleSavePath), f"{model_name}.joblib")
        if not os.path.exists(model_file):
            print(f"模型文件 {model_file} 不存在，请检查模型名称。")
            return
        
        # 预处理验证数据
        validDatasetCSVRootDir = get_full_path(validDatasetCSV)
        validate_model(model_file, validDatasetCSVRootDir)

    elif mode == 'submit':
        # 生成 Kaggle 提交文件
        from valid import generate_kaggle_submission
        
        model_name = input("请输入已训练模型的名称 (例如 'trained_model'): ").strip()
        model_file = os.path.join(get_full_path(moduleSavePath), f"{model_name}.joblib")
        if not os.path.exists(model_file):
            print(f"模型文件 {model_file} 不存在，请检查模型名称。")
            return
        
        test_file = input("请输入测试数据文件路径 (例如 'data/test.csv'): ").strip()
        test_file_full = get_full_path(test_file) if not os.path.isabs(test_file) else test_file
        
        output_file = input("请输入输出文件名 (默认 'submission.csv'，直接回车使用默认): ").strip()
        if not output_file:
            output_file = 'submission.csv'
        
        generate_kaggle_submission(model_file, test_file_full, output_file)

    else:
        print("无效的模式输入，请输入 'train'、'valid' 或 'submit'。")


# 运行主程序
if __name__ == '__main__':
    main()