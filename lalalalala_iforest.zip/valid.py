import pandas as pd
import joblib
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.metrics import average_precision_score, roc_auc_score, precision_recall_curve, roc_curve
import os


def preprocess_for_validation(input_filepath: str):
    """
    加载并预处理用于验证的数据。
    这个函数必须与训练时的预处理函数保持一致。
    """
    if not os.path.exists(input_filepath):
        print(f"错误: 验证文件 '{input_filepath}' 未找到。请确保文件名正确并且文件存在。")
        return None, None

    print("开始预处理验证数据...")
    df = pd.read_csv(input_filepath)

    # 检查所有必需的列是否存在
    required_cols = ['eventId', 'argsNum', 'processId', 'parentProcessId', 'userId', 'mountNamespace', 'returnValue',
                     'target']
    if not all(col in df.columns for col in required_cols):
        print(f"错误: 验证文件缺少必要的列。需要: {required_cols}")
        return None, None

    # 分离特征和真实标签
    y_true = df['target']
    features_df = df.drop('target', axis=1)

    processed_df = pd.DataFrame()

    # 应用与训练时完全相同的特征转换
    processed_df['eventId'] = features_df['eventId']
    processed_df['argsNum'] = features_df['argsNum']
    processed_df['processId_is_os'] = features_df['processId'].isin([0, 1, 2]).astype(int)
    processed_df['parentProcessId_is_os'] = features_df['parentProcessId'].isin([0, 1, 2]).astype(int)
    processed_df['userId_is_os'] = (features_df['userId'] < 1000).astype(int)
    processed_df['mountNamespace_is_default'] = (features_df['mountNamespace'] == 4026531840).astype(int)
    processed_df['returnValue_mapped'] = features_df['returnValue'].apply(
        lambda x: -1 if x < 0 else (0 if x == 0 else 1))

    print("验证数据预处理完成。")
    return processed_df, y_true


def validate_model(model_path: str, validation_data_path: str):
    """
    加载模型并在验证集上进行评估。
    支持单模型和集成模型两种模式。
    """
    if not os.path.exists(model_path):
        print(f"错误: 模型文件 '{model_path}' 未找到。")
        return

    # 1. 加载模型
    print(f"\n正在加载模型: {model_path}")
    loaded_model = joblib.load(model_path)

    # 2. 加载并预处理验证数据
    X_valid, y_valid = preprocess_for_validation(validation_data_path)

    if X_valid is None:
        print("由于数据预处理失败，验证中止。")
        return

    # 3. 获取异常概率分数（用于 Kaggle 评估）
    if isinstance(loaded_model, dict) and 'model_type' in loaded_model:
        model_type = loaded_model.get('model_type')
        if model_type == 'ensemble_v2':
            print("检测到增强集成模型 (v2)，计算异常概率分数...\n")
            y_scores = _get_anomaly_scores_v2(loaded_model, X_valid)
        elif model_type == 'ensemble':
            print("检测到集成模型 (v1)，计算异常概率分数...\n")
            y_scores = _get_anomaly_scores(loaded_model, X_valid)
        else:
            print("检测到单一模型，计算异常概率分数...\n")
            scores = loaded_model.score_samples(X_valid)
            y_scores = -scores  # 转换为异常分数（越高越异常）
    else:
        print("检测到单一模型，计算异常概率分数...\n")
        scores = loaded_model.score_samples(X_valid)
        y_scores = -scores  # 转换为异常分数（越高越异常）
    
    # 归一化分数到 [0, 1] 范围（作为异常概率）
    y_proba = (y_scores - y_scores.min()) / (y_scores.max() - y_scores.min() + 1e-10)

    # 4. 计算 Kaggle 评估指标
    print("\n" + "=" * 70)
    print("              🎯 KAGGLE 评估指标 (Threshold-Free)")
    print("=" * 70)
    
    # 主要指标：Average Precision
    ap_score = average_precision_score(y_valid, y_proba)
    print(f"\n⭐ Average Precision (AP): {ap_score:.4f}  ← KAGGLE 主要评分")
    
    # Tie-breaker：ROC-AUC
    roc_auc = roc_auc_score(y_valid, y_proba)
    print(f"⭐ ROC-AUC Score:          {roc_auc:.4f}  ← KAGGLE Tie-breaker")
    
    print(f"\n💡 说明: 这两个指标都是基于概率分数，与 Kaggle 评估一致")
    print(f"   分数越接近 1.0 越好，当前 AP={ap_score:.4f}")
    
    # 5. 生成硬分类结果（用于参考）
    # 使用最优阈值
    precision, recall, thresholds = precision_recall_curve(y_valid, y_proba)
    f1_scores = 2 * (precision * recall) / (precision + recall + 1e-10)
    optimal_idx = np.argmax(f1_scores[:-1])  # 排除最后一个点
    optimal_threshold = thresholds[optimal_idx] if optimal_idx < len(thresholds) else 0.5
    
    y_pred = (y_proba >= optimal_threshold).astype(int)
    
    print("\n" + "=" * 70)
    print("              📊 硬分类性能 (仅供参考，非 Kaggle 评估)")
    print("=" * 70)
    print(f"\n使用最优阈值: {optimal_threshold:.4f}")

    accuracy = accuracy_score(y_valid, y_pred)
    print(f"整体准确率 (Accuracy): {accuracy:.4f}")

    print("\n分类报告 (Classification Report):")
    print(classification_report(y_valid, y_pred, target_names=['正常 (class 0)', '异常 (class 1)'], digits=4))

    print("混淆矩阵 (Confusion Matrix):")
    cm = confusion_matrix(y_valid, y_pred)
    print(cm)
    print("\n混淆矩阵解读:")
    print(f"  [[  True Negatives (TN) | False Positives (FP) ]]")
    print(f"  [[ False Negatives (FN) |  True Positives (TP) ]]")
    print(f"\n  TN: {cm[0][0]},  FP: {cm[0][1]}")
    print(f"  FN: {cm[1][0]},  TP: {cm[1][1]}")
    
    # 计算额外的评估指标
    if cm[1][1] + cm[1][0] > 0:  # 避免除零
        recall_anomaly = cm[1][1] / (cm[1][1] + cm[1][0])
        print(f"\n  Recall (异常类): {recall_anomaly:.4f}")
    
    if cm[1][1] + cm[0][1] > 0:  # 避免除零
        precision_anomaly = cm[1][1] / (cm[1][1] + cm[0][1])
        print(f"  Precision (异常类): {precision_anomaly:.4f}")
    
    print("\n" + "=" * 70)
    print(f"💡 提示: Kaggle 提交时使用异常概率分数 (0-1之间的连续值)")
    print(f"   不需要硬分类，系统会自动计算 Average Precision")
    print("=" * 70)


def _get_anomaly_scores_v2(ensemble_model: dict, X_valid: pd.DataFrame) -> np.ndarray:
    """
    使用增强集成模型计算异常分数（用于 Average Precision 评估）。
    返回连续的异常分数，越高表示越可能是异常。
    
    Args:
        ensemble_model: 包含4个模型的字典
        X_valid: 验证数据
    
    Returns:
        异常分数数组 (连续值，越高越异常)
    """
    # 提取模型和scaler
    model_if1 = ensemble_model['isolation_forest']
    model_if2 = ensemble_model['isolation_forest_v2']
    model_lof = ensemble_model['local_outlier_factor']
    model_svm = ensemble_model['one_class_svm']
    scaler = ensemble_model['scaler']
    
    # 标准化数据
    X_valid_scaled = scaler.transform(X_valid)
    
    print("计算4个模型的异常分数...")
    
    # 获取每个模型的异常分数（越低越异常，需要取反）
    score_if1 = -model_if1.score_samples(X_valid)  # 取负，越高越异常
    score_if2 = -model_if2.score_samples(X_valid)
    score_lof = -model_lof.score_samples(X_valid_scaled)
    score_svm = -model_svm.score_samples(X_valid_scaled)
    
    # 归一化每个分数到 [0, 1]
    def normalize_score(score):
        score_min, score_max = score.min(), score.max()
        if score_max - score_min < 1e-10:
            return np.zeros_like(score)
        return (score - score_min) / (score_max - score_min)
    
    score_if1_norm = normalize_score(score_if1)
    score_if2_norm = normalize_score(score_if2)
    score_lof_norm = normalize_score(score_lof)
    score_svm_norm = normalize_score(score_svm)
    
    # 加权融合（与预测时一致）
    weighted_anomaly_score = (
        0.3 * score_if1_norm +   # IF主模型 30%
        0.3 * score_if2_norm +   # IF变体 30%
        0.2 * score_lof_norm +   # LOF 20%
        0.2 * score_svm_norm     # SVM 20%
    )
    
    print(f"✓ 异常分数计算完成 (范围: {weighted_anomaly_score.min():.4f} - {weighted_anomaly_score.max():.4f})")
    
    return weighted_anomaly_score


def _get_anomaly_scores(ensemble_model: dict, X_valid: pd.DataFrame) -> np.ndarray:
    """
    使用集成模型计算异常分数（v1版本）。
    返回连续的异常分数，越高表示越可能是异常。
    
    Args:
        ensemble_model: 包含3个模型的字典
        X_valid: 验证数据
    
    Returns:
        异常分数数组 (连续值，越高越异常)
    """
    # 提取模型和scaler
    model_if = ensemble_model['isolation_forest']
    model_lof = ensemble_model['local_outlier_factor']
    model_svm = ensemble_model['one_class_svm']
    scaler = ensemble_model['scaler']
    
    # 标准化数据
    X_valid_scaled = scaler.transform(X_valid)
    
    print("计算3个模型的异常分数...")
    
    # 获取每个模型的异常分数（取负，越高越异常）
    score_if = -model_if.score_samples(X_valid)
    score_lof = -model_lof.score_samples(X_valid_scaled)
    score_svm = -model_svm.score_samples(X_valid_scaled)
    
    # 归一化
    def normalize_score(score):
        score_min, score_max = score.min(), score.max()
        if score_max - score_min < 1e-10:
            return np.zeros_like(score)
        return (score - score_min) / (score_max - score_min)
    
    score_if_norm = normalize_score(score_if)
    score_lof_norm = normalize_score(score_lof)
    score_svm_norm = normalize_score(score_svm)
    
    # 均等加权融合
    weighted_anomaly_score = (score_if_norm + score_lof_norm + score_svm_norm) / 3.0
    
    print(f"✓ 异常分数计算完成")
    
    return weighted_anomaly_score


def _predict_ensemble_v2(ensemble_model: dict, X_valid: pd.DataFrame) -> np.ndarray:
    """
    使用增强集成模型进行预测（v2版本）。
    采用4个模型的严格投票策略 + 智能分数融合。
    
    Args:
        ensemble_model: 包含4个模型的字典
        X_valid: 验证数据
    
    Returns:
        预测结果数组 (0=正常, 1=异常)
    """
    # 提取模型和scaler
    model_if1 = ensemble_model['isolation_forest']
    model_if2 = ensemble_model['isolation_forest_v2']
    model_lof = ensemble_model['local_outlier_factor']
    model_svm = ensemble_model['one_class_svm']
    scaler = ensemble_model['scaler']
    contamination = ensemble_model.get('contamination', 0.04)
    
    # 标准化数据（用于LOF和SVM）
    X_valid_scaled = scaler.transform(X_valid)
    
    print("=" * 60)
    print("执行增强多模型集成预测 (4模型严格策略)...")
    print("=" * 60)
    
    # 获取每个模型的预测和分数
    print("\n[1/4] Isolation Forest (主模型) 预测中...")
    pred_if1 = model_if1.predict(X_valid)
    score_if1 = model_if1.score_samples(X_valid)
    pred_if1_binary = np.array([1 if p == -1 else 0 for p in pred_if1])
    print(f"      检测到 {np.sum(pred_if1_binary)} 个异常样本")
    
    print("\n[2/4] Isolation Forest (变体) 预测中...")
    pred_if2 = model_if2.predict(X_valid)
    score_if2 = model_if2.score_samples(X_valid)
    pred_if2_binary = np.array([1 if p == -1 else 0 for p in pred_if2])
    print(f"      检测到 {np.sum(pred_if2_binary)} 个异常样本")
    
    print("\n[3/4] Local Outlier Factor 预测中...")
    pred_lof = model_lof.predict(X_valid_scaled)
    score_lof = model_lof.score_samples(X_valid_scaled)
    pred_lof_binary = np.array([1 if p == -1 else 0 for p in pred_lof])
    print(f"      检测到 {np.sum(pred_lof_binary)} 个异常样本")
    
    print("\n[4/4] One-Class SVM 预测中...")
    pred_svm = model_svm.predict(X_valid_scaled)
    score_svm = model_svm.score_samples(X_valid_scaled)
    pred_svm_binary = np.array([1 if p == -1 else 0 for p in pred_svm])
    print(f"      检测到 {np.sum(pred_svm_binary)} 个异常样本")
    
    print("\n" + "=" * 60)
    print("应用优化集成策略:")
    print("  1. 严格投票: 至少3个模型同意")
    print("  2. 加权分数: 基于模型可靠性")
    print("  3. 自适应阈值: 基于训练时contamination")
    print("=" * 60)
    
    # 策略1: 严格多数投票 (至少3/4个模型认为是异常)
    vote_sum = pred_if1_binary + pred_if2_binary + pred_lof_binary + pred_svm_binary
    strict_vote = (vote_sum >= 3).astype(int)  # 至少3个模型同意
    
    # 策略2: 加权分数融合
    # 归一化分数到[0,1]范围，分数越低越异常
    def normalize_score(score):
        score_min, score_max = score.min(), score.max()
        if score_max - score_min < 1e-10:
            return np.zeros_like(score)
        return (score - score_min) / (score_max - score_min)
    
    score_if1_norm = normalize_score(score_if1)
    score_if2_norm = normalize_score(score_if2)
    score_lof_norm = normalize_score(score_lof)
    score_svm_norm = normalize_score(score_svm)
    
    # 加权平均（IF模型权重更高，因为它们对异常检测更稳健）
    weighted_score = (
        0.3 * score_if1_norm +   # IF主模型 30%
        0.3 * score_if2_norm +   # IF变体 30%
        0.2 * score_lof_norm +   # LOF 20%
        0.2 * score_svm_norm     # SVM 20%
    )
    
    # 使用更严格的阈值（基于contamination参数）
    # 只取最异常的样本
    threshold_percentile = contamination * 100  # 转换为百分位数
    score_threshold = np.percentile(weighted_score, threshold_percentile)
    score_based_pred = (weighted_score <= score_threshold).astype(int)
    
    # 最终策略：严格投票 OR (至少2个模型同意 AND 分数很低)
    moderate_vote = (vote_sum >= 2).astype(int)
    final_pred = np.where(
        (strict_vote == 1) | ((moderate_vote == 1) & (score_based_pred == 1)),
        1, 
        0
    )
    
    # 输出统计信息
    print(f"\n检测结果统计:")
    print(f"  - 严格投票 (≥3个模型): {np.sum(strict_vote)} 个异常")
    print(f"  - 中等投票 (≥2个模型): {np.sum(moderate_vote)} 个异常")
    print(f"  - 分数阈值检测: {np.sum(score_based_pred)} 个异常")
    print(f"  - 最终集成检测: {np.sum(final_pred)} 个异常")
    print(f"  - 异常比例: {np.sum(final_pred)/len(final_pred)*100:.2f}%")
    
    return final_pred


def _predict_ensemble(ensemble_model: dict, X_valid: pd.DataFrame) -> np.ndarray:
    """
    使用集成模型进行预测，采用多数投票和分数加权策略。
    
    Args:
        ensemble_model: 包含多个模型的字典
        X_valid: 验证数据
    
    Returns:
        预测结果数组 (0=正常, 1=异常)
    """
    # 提取模型和scaler
    model_if = ensemble_model['isolation_forest']
    model_lof = ensemble_model['local_outlier_factor']
    model_svm = ensemble_model['one_class_svm']
    scaler = ensemble_model['scaler']
    
    # 标准化数据（用于LOF和SVM）
    X_valid_scaled = scaler.transform(X_valid)
    
    print("=" * 60)
    print("执行多模型集成预测...")
    print("=" * 60)
    
    # 获取每个模型的预测
    print("\n[1/3] Isolation Forest 预测中...")
    pred_if = model_if.predict(X_valid)
    score_if = model_if.score_samples(X_valid)  # 异常分数（越低越异常）
    pred_if_binary = np.array([1 if p == -1 else 0 for p in pred_if])
    anomaly_count_if = np.sum(pred_if_binary)
    print(f"      检测到 {anomaly_count_if} 个异常样本")
    
    print("\n[2/3] Local Outlier Factor 预测中...")
    pred_lof = model_lof.predict(X_valid_scaled)
    score_lof = model_lof.score_samples(X_valid_scaled)
    pred_lof_binary = np.array([1 if p == -1 else 0 for p in pred_lof])
    anomaly_count_lof = np.sum(pred_lof_binary)
    print(f"      检测到 {anomaly_count_lof} 个异常样本")
    
    print("\n[3/3] One-Class SVM 预测中...")
    pred_svm = model_svm.predict(X_valid_scaled)
    score_svm = model_svm.score_samples(X_valid_scaled)
    pred_svm_binary = np.array([1 if p == -1 else 0 for p in pred_svm])
    anomaly_count_svm = np.sum(pred_svm_binary)
    print(f"      检测到 {anomaly_count_svm} 个异常样本")
    
    print("\n" + "=" * 60)
    print("应用集成策略: 多数投票 + 分数加权")
    print("=" * 60)
    
    # 策略1: 简单多数投票
    vote_sum = pred_if_binary + pred_lof_binary + pred_svm_binary
    majority_vote = (vote_sum >= 2).astype(int)  # 至少2个模型认为是异常
    
    # 策略2: 加权投票（基于异常分数）
    # 归一化分数到[0,1]范围，分数越低越异常
    score_if_norm = (score_if - score_if.min()) / (score_if.max() - score_if.min() + 1e-10)
    score_lof_norm = (score_lof - score_lof.min()) / (score_lof.max() - score_lof.min() + 1e-10)
    score_svm_norm = (score_svm - score_svm.min()) / (score_svm.max() - score_svm.min() + 1e-10)
    
    # 综合分数（越低越异常）
    combined_score = (score_if_norm + score_lof_norm + score_svm_norm) / 3.0
    
    # 最终预测：结合投票和分数
    # 如果多数投票认为是异常，或者综合分数很低（前10%），则判定为异常
    threshold = np.percentile(combined_score, 10)
    final_pred = np.where((majority_vote == 1) | (combined_score < threshold), 1, 0)
    
    anomaly_count_final = np.sum(final_pred)
    print(f"\n最终集成结果: 检测到 {anomaly_count_final} 个异常样本")
    print(f"  - 多数投票检测: {np.sum(majority_vote)} 个")
    print(f"  - 分数阈值检测: {np.sum(combined_score < threshold)} 个")
    print(f"  - 集成后检测: {anomaly_count_final} 个")
    
    return final_pred


def generate_kaggle_submission(model_path: str, test_data_path: str, output_path: str = 'submission.csv'):
    """
    为 Kaggle 生成提交文件。
    
    Args:
        model_path: 训练好的模型文件路径
        test_data_path: 测试数据 CSV 路径（不含 target 列）
        output_path: 输出的提交文件路径
    """
    if not os.path.exists(model_path):
        print(f"错误: 模型文件 '{model_path}' 未找到。")
        return
    
    # 1. 加载模型
    print(f"\n正在加载模型: {model_path}")
    loaded_model = joblib.load(model_path)
    
    # 2. 加载并预处理测试数据
    print(f"正在加载测试数据: {test_data_path}")
    if not os.path.exists(test_data_path):
        print(f"错误: 测试文件 '{test_data_path}' 未找到。")
        return
    
    df = pd.read_csv(test_data_path)
    
    # 假设有 id 列，如果没有则创建
    if 'id' in df.columns:
        test_ids = df['id'].values
        df = df.drop('id', axis=1)
    else:
        test_ids = np.arange(len(df))
    
    # 预处理（与训练时相同）
    if 'target' in df.columns:
        df = df.drop('target', axis=1)
    
    print("预处理测试数据...")
    processed_df = pd.DataFrame()
    processed_df['eventId'] = df['eventId']
    processed_df['argsNum'] = df['argsNum']
    processed_df['processId_is_os'] = df['processId'].isin([0, 1, 2]).astype(int)
    processed_df['parentProcessId_is_os'] = df['parentProcessId'].isin([0, 1, 2]).astype(int)
    processed_df['userId_is_os'] = (df['userId'] < 1000).astype(int)
    processed_df['mountNamespace_is_default'] = (df['mountNamespace'] == 4026531840).astype(int)
    processed_df['returnValue_mapped'] = df['returnValue'].apply(lambda x: -1 if x < 0 else (0 if x == 0 else 1))
    
    # 3. 获取异常概率分数
    print("\n计算异常概率分数...")
    if isinstance(loaded_model, dict) and 'model_type' in loaded_model:
        model_type = loaded_model.get('model_type')
        if model_type == 'ensemble_v2':
            y_scores = _get_anomaly_scores_v2(loaded_model, processed_df)
        elif model_type == 'ensemble':
            y_scores = _get_anomaly_scores(loaded_model, processed_df)
        else:
            scores = loaded_model.score_samples(processed_df)
            y_scores = -scores
    else:
        scores = loaded_model.score_samples(processed_df)
        y_scores = -scores
    
    # 归一化到 [0, 1]
    y_proba = (y_scores - y_scores.min()) / (y_scores.max() - y_scores.min() + 1e-10)
    
    # 4. 生成提交文件
    submission_df = pd.DataFrame({
        'id': test_ids,
        'target': y_proba  # 异常概率（0-1之间的连续值）
    })
    
    submission_df.to_csv(output_path, index=False)
    print(f"\n✓ Kaggle 提交文件已保存到: '{output_path}'")
    print(f"  - 样本数量: {len(submission_df)}")
    print(f"  - 预测分数范围: [{y_proba.min():.4f}, {y_proba.max():.4f}]")
    print(f"  - 平均异常概率: {y_proba.mean():.4f}")
    print(f"\n💡 提交文件格式: id, target (异常概率)")
    print(f"   可直接上传到 Kaggle 进行评估！")


# --- 主程序入口 ---
if __name__ == '__main__':
    # --- 请在这里配置您的文件名 ---
    MODEL_FILE = 'isolation_forest_model.joblib'
    VALIDATION_CSV = '/Users/hardycheng/Desktop/NUS_Sem1_course/1_Big-data/Projects/Full_Datasets/Track3/processes_train.csv'

    validate_model(MODEL_FILE, VALIDATION_CSV)