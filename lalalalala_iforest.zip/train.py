import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM
from sklearn.preprocessing import StandardScaler
import joblib
import os
import numpy as np

def preprocess_for_training(input_filepath: str):
    """
    加载并预处理用于训练的数据。
    在无监督训练中，我们不需要 'target' 列。
    """
    if not os.path.exists(input_filepath):
        print(f"错误: 输入文件 '{input_filepath}' 未找到。请确保它和脚本在同一个目录下。")
        return None

    print("开始预处理数据...")
    df = pd.read_csv(input_filepath)

    # 在进行无监督学习训练时，我们不需要目标标签
    if 'target' in df.columns:
        df = df.drop('target', axis=1)

    # 检查所有必需的特征列是否存在
    required_features = ['eventId', 'argsNum', 'processId', 'parentProcessId', 'userId', 'mountNamespace',
                         'returnValue']
    if not all(col in df.columns for col in required_features):
        print(f"错误: CSV文件缺少必要的特征列。需要: {required_features}")
        return None

    processed_df = pd.DataFrame()

    # 根据论文进行特征转换
    processed_df['eventId'] = df['eventId']
    processed_df['argsNum'] = df['argsNum']
    processed_df['processId_is_os'] = df['processId'].isin([0, 1, 2]).astype(int)
    processed_df['parentProcessId_is_os'] = df['parentProcessId'].isin([0, 1, 2]).astype(int)
    processed_df['userId_is_os'] = (df['userId'] < 1000).astype(int)
    processed_df['mountNamespace_is_default'] = (df['mountNamespace'] == 4026531840).astype(int)
    processed_df['returnValue_mapped'] = df['returnValue'].apply(lambda x: -1 if x < 0 else (0 if x == 0 else 1))

    print("数据预处理完成。")
    return processed_df

def train_and_save_model(data: pd.DataFrame, model_save_path: str):
    """
    使用集成方法训练多个异常检测模型并保存。
    采用 Isolation Forest、Local Outlier Factor 和 One-Class SVM 三个模型。
    """
    if data is None:
        print("没有可用于训练的数据。")
        return

    print("\n=" * 60)
    print("开始训练多模型集成异常检测系统...")
    print("=" * 60)

    # 数据标准化（对于 LOF 和 One-Class SVM 很重要）
    print("\n[1/6] 数据标准化...")
    scaler = StandardScaler()
    data_scaled = scaler.fit_transform(data)
    
    # 根据数据集实际情况优化参数
    # 典型异常比例约为 3-5%，使用更保守的设置
    contamination_ratio = 0.04  # 4% 更接近实际异常比例
    
    # 💡 速度优化：对于大数据集，减少树的数量和使用采样
    data_size = len(data)
    print(f"   数据集大小: {data_size:,} 行")
    
    # 根据数据大小自适应调整参数
    if data_size > 500000:
        n_trees = 150        # 大数据集使用较少的树
        max_samples = 20000  # 限制每棵树的样本数
        print("   检测到大数据集，启用快速训练模式")
    elif data_size > 100000:
        n_trees = 200
        max_samples = 50000
        print("   检测到中等数据集，使用平衡模式")
    else:
        n_trees = 300
        max_samples = 'auto'
        print("   检测到小数据集，使用完整训练模式")
    
    # 初始化多个不同的异常检测模型（优化训练速度）
    print("\n[2/6] 训练 Isolation Forest 模型（主模型）...")
    # Isolation Forest: 基于随机森林的异常检测，对高维数据效果好
    model_if = IsolationForest(
        contamination=contamination_ratio,
        random_state=42, 
        n_estimators=n_trees,      # 自适应树数量
        max_samples=max_samples,   # 限制样本数加速训练
        max_features=1.0,
        n_jobs=-1,
        verbose=0                  # 减少输出
    )
    model_if.fit(data)
    print("   ✓ Isolation Forest 训练完成")

    print("\n[3/6] 训练 Local Outlier Factor 模型...")
    # Local Outlier Factor: 基于局部密度的异常检测，对局部异常敏感
    # 💡 速度优化：减少邻居数，对大数据集很有效
    n_neighbors_opt = min(30, max(20, data_size // 20000))  # 自适应邻居数
    model_lof = LocalOutlierFactor(
        contamination=contamination_ratio,
        n_neighbors=n_neighbors_opt,  # 优化的邻居数
        novelty=True,
        n_jobs=-1,
        algorithm='auto'  # 自动选择最快的算法
    )
    model_lof.fit(data_scaled)
    print(f"   ✓ Local Outlier Factor 训练完成 (n_neighbors={n_neighbors_opt})")

    print("\n[4/6] 训练 One-Class SVM 模型...")
    # One-Class SVM: 对大数据集较慢，使用采样加速
    # 💡 速度优化：对超大数据集进行采样
    if data_size > 100000:
        sample_size = min(100000, data_size)
        sample_indices = np.random.choice(data_size, sample_size, replace=False)
        data_scaled_sampled = data_scaled[sample_indices]
        print(f"   使用 {sample_size:,} 样本进行 SVM 训练（加速）")
    else:
        data_scaled_sampled = data_scaled
    
    model_svm = OneClassSVM(
        kernel='rbf',
        gamma='scale',
        nu=contamination_ratio,
        cache_size=500  # 增加缓存加速
    )
    model_svm.fit(data_scaled_sampled)
    print("   ✓ One-Class SVM 训练完成")
    
    print("\n[5/6] 训练额外的 Isolation Forest 模型（不同参数）...")
    # 第二个 IF 模型，使用不同的参数配置增加多样性
    model_if2 = IsolationForest(
        contamination=contamination_ratio,
        random_state=123,
        n_estimators=n_trees,      # 与主模型一致
        max_samples=min(20000, max_samples) if max_samples != 'auto' else 20000,  # 更小的采样
        max_features=0.8,
        n_jobs=-1,
        verbose=0
    )
    model_if2.fit(data)
    print("   ✓ Isolation Forest (变体) 训练完成")

    # 将所有模型和scaler打包保存
    print("\n[6/6] 保存集成模型...")
    ensemble_model = {
        'isolation_forest': model_if,
        'isolation_forest_v2': model_if2,  # 添加第二个IF模型
        'local_outlier_factor': model_lof,
        'one_class_svm': model_svm,
        'scaler': scaler,
        'model_type': 'ensemble_v2',  # 标记为v2版本
        'contamination': contamination_ratio
    }

    try:
        joblib.dump(ensemble_model, model_save_path)
        print(f"\n{'=' * 60}")
        print(f"✓ 增强集成模型已成功保存到: '{model_save_path}'")
        print(f"  - 包含模型: IF×2, LOF, One-Class SVM (共4个模型)")
        print(f"  - 异常比例设置: {contamination_ratio*100:.1f}%")
        print(f"  - 检测策略: 加权投票 + 自适应阈值")
        print(f"{'=' * 60}")
    except Exception as e:
        print(f"保存模型时出错: {e}")


# --- 主程序入口 ---
if __name__ == '__main__':
    # 定义输入和输出文件名
    input_csv = '/Users/hardycheng/Desktop/NUS_Sem1_course/1_Big-data/Projects/Full_Datasets/Track3/processes_train.csv'
    model_output_file = 'isolation_forest_model.joblib'

    # 步骤 1: 预处理数据
    processed_training_data = preprocess_for_training(input_csv)

    # 步骤 2: 如果预处理成功，则训练并保存模型
    if processed_training_data is not None:
        train_and_save_model(processed_training_data, model_output_file)
    else:
        print("\n由于预处理失败，模型训练被中止。")