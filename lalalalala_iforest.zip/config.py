trainDatasetCSV = '/data/processes_train.csv'
validDatasetCSV = '/data/processes_valid.csv'
moduleSavePath = '/savedModule/'  # 保存模型的目录